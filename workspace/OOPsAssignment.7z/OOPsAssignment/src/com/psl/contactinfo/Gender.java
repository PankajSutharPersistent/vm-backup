package com.psl.contactinfo;

public enum Gender {
	MALE,FEMALE;

}
